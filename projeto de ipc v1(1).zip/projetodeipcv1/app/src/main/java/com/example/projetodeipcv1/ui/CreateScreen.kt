package com.example.projetodeipcv1.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateScreen(navController: NavController) {
    val context = LocalContext.current
    val calendar = Calendar.getInstance()

    val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    val sdfHour = SimpleDateFormat("HH:mm", Locale.getDefault())

    var titulo by remember { mutableStateOf("") }
    var descricao by remember { mutableStateOf("") }
    var importancia by remember { mutableStateOf(Importancia.MEDIA) }
    var etiquetaSelecionada by remember { mutableStateOf("Geral") }
    var etiquetaExpanded by remember { mutableStateOf(false) }
    var erroTitulo by remember { mutableStateOf(false) }
    var date by remember { mutableStateOf(sdf.format(calendar.time)) }
    var hour by remember { mutableStateOf(sdfHour.format(calendar.time)) }

    val datePickerDialog = DatePickerDialog(
        context,
        { _, year, month, day ->
            date = "%02d/%02d/%04d".format(day, month + 1, year)
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    )

    val timePickerDialog = TimePickerDialog(
        context,
        { _, hourOfDay, minute ->
            hour = "%02d:%02d".format(hourOfDay, minute)
        },
        calendar.get(Calendar.HOUR_OF_DAY),
        calendar.get(Calendar.MINUTE),
        true
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Nova Tarefa") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = titulo,
                onValueChange = { titulo = it; erroTitulo = false },
                label = { Text("Título *") },
                isError = erroTitulo,
                supportingText = { if (erroTitulo) Text("O título é obrigatório") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = descricao,
                onValueChange = { descricao = it },
                label = { Text("Descrição") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3
            )

            Button(
                onClick = { datePickerDialog.show() },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                )
            ) {
                Text("Data: $date")
            }

            Button(
                onClick = { timePickerDialog.show() },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                )
            ) {
                Text("Hora: $hour")
            }

            Text("Nível de Importância", style = MaterialTheme.typography.labelLarge)
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                listOf(
                    Triple(Importancia.BAIXA, "Baixa", Color(0xFF4CAF50)),
                    Triple(Importancia.MEDIA, "Média", Color(0xFFFFC107)),
                    Triple(Importancia.ALTA, "Alta", Color(0xFFF44336))
                ).forEach { (nivel, label, cor) ->
                    FilterChip(
                        selected = importancia == nivel,
                        onClick = { importancia = nivel },
                        label = { Text(label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = cor,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Text("Etiqueta", style = MaterialTheme.typography.labelLarge)
            ExposedDropdownMenuBox(
                expanded = etiquetaExpanded,
                onExpandedChange = { etiquetaExpanded = it }
            ) {
                OutlinedTextField(
                    value = etiquetaSelecionada,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Categoria") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = etiquetaExpanded) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = etiquetaExpanded,
                    onDismissRequest = { etiquetaExpanded = false }
                ) {
                    listOf("Geral", "Pessoal", "Trabalho", "Saúde", "Escola").forEach { etiqueta ->
                        DropdownMenuItem(
                            text = { Text(etiqueta) },
                            onClick = {
                                etiquetaSelecionada = etiqueta
                                etiquetaExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    if (titulo.isBlank()) {
                        erroTitulo = true
                    } else {
                        reminders.add(
                            Reminder(
                                title = titulo,
                                date = date,
                                hour = hour,
                                description = descricao,
                                importancia = importancia,
                                etiqueta = etiquetaSelecionada
                            )
                        )
                        mensagemSnackbar = "Lembrete criado"
                        navController.popBackStack()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Guardar")
            }
        }
    }
}