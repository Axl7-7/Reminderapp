package com.example.projetodeipcv1

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.projetodeipcv1.ui.CalendarScreen
import com.example.projetodeipcv1.ui.CreateScreen
import com.example.projetodeipcv1.ui.DetailScreen
import com.example.projetodeipcv1.ui.EditScreen
import com.example.projetodeipcv1.ui.HomeScreen
import com.example.projetodeipcv1.ui.SettingsScreen

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "home"
    ) {
        composable("home") {
            HomeScreen(navController = navController)
        }
        composable("create") {
            CreateScreen(navController = navController)
        }
        composable("detail/{index}") { backStackEntry ->
            val index = backStackEntry.arguments?.getString("index")?.toIntOrNull() ?: 0
            DetailScreen(navController = navController, index = index)
        }
        composable("edit/{index}") { backStackEntry ->
            val index = backStackEntry.arguments?.getString("index")?.toIntOrNull() ?: 0
            EditScreen(navController = navController, index = index)
        }
        composable("calendar") {
            CalendarScreen(navController = navController)
        }

        composable("settings") {
            SettingsScreen(navController = navController)
        }
        }
    }
