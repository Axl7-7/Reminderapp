package com.example.projetodeipcv1.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: NavController) {
    var escala by remember { AppSettings.fontScale }

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("Definições") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            Text("Tamanho da Letra", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            Text("Exemplo de texto com o tamanho atual", fontSize = MaterialTheme.typography.bodyLarge.fontSize)

            Slider(
                value = escala,
                onValueChange = {
                    escala = it
                    AppSettings.fontScale.floatValue = it
                },
                valueRange = 0.8f..1.5f,
                steps = 6
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Pequena", style = MaterialTheme.typography.bodySmall)
                Text("Grande", style = MaterialTheme.typography.bodySmall)
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            Text(
                "Lembretes Apagados (${deletedReminders.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            if (deletedReminders.isEmpty()) {
                Text(
                    "Nenhum lembrete apagado",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(deletedReminders) { reminder ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(reminder.title, fontWeight = FontWeight.Bold)
                                    Text(
                                        "Data: ${reminder.date} - Hora: ${reminder.hour}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = {
                                    reminders.add(reminder)
                                    deletedReminders.remove(reminder)
                                    scope.launch {
                                        snackbarHostState.showSnackbar("Lembrete restaurado")
                                    }
                                }) {
                                    Icon(Icons.Default.Refresh, contentDescription = "Restaurar")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}