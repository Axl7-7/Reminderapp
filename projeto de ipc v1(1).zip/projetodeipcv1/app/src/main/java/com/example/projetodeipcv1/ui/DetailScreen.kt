package com.example.projetodeipcv1.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(navController: NavController, index: Int) {
    val reminder = reminders.getOrNull(index) ?: return

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Detalhe do Lembrete") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Título e etiqueta
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .width(8.dp)
                        .height(40.dp)
                        .background(
                            color = corImportancia(reminder.importancia),
                            shape = RoundedCornerShape(4.dp)
                        )
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = reminder.title,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = reminder.etiqueta,
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            HorizontalDivider()

            // Descrição
            Text(
                text = "Descrição",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = if (reminder.description.isNotBlank()) reminder.description else "Sem descrição",
                style = MaterialTheme.typography.bodyLarge
            )

            // Data e Hora
            Text(
                text = "Data e Hora",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "${reminder.date} às ${reminder.hour}",
                style = MaterialTheme.typography.bodyLarge
            )

            // Importância
            Text(
                text = "Importância",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .background(
                            color = corImportancia(reminder.importancia),
                            shape = RoundedCornerShape(4.dp)
                        )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = when (reminder.importancia) {
                        Importancia.BAIXA -> "Baixa"
                        Importancia.MEDIA -> "Média"
                        Importancia.ALTA  -> "Alta"
                    },
                    style = MaterialTheme.typography.bodyLarge
                )
            }

            // Estado
            Text(
                text = "Estado",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = if (reminder.done) "✅ Concluído" else "⏳ Pendente",
                style = MaterialTheme.typography.bodyLarge
            )

            Spacer(modifier = Modifier.weight(1f))

            // Botão 1 — Concluído
            Button(
                onClick = {
                    reminders[index] = reminder.copy(done = true)
                    navController.popBackStack()
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF4CAF50)
                )
            ) {
                Text("Marcar como Concluído")
            }

            // Botão 2 — Editar
            Button(
                onClick = { navController.navigate("edit/$index") },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Editar Lembrete")
            }

            // Botão 3 — Apagar
            Button(
                onClick = {
                    deletedReminders.add(reminder)
                    reminders.removeAt(index)
                    mensagemSnackbar = "Lembrete apagado"
                    navController.popBackStack()
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error
                )
            ) {
                Text("Apagar")
            }
        }
    }
}