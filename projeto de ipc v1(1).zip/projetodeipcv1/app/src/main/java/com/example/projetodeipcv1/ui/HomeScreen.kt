package com.example.projetodeipcv1.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import kotlinx.coroutines.launch

enum class Importancia {
    BAIXA, MEDIA, ALTA
}

data class Reminder(
    val title: String,
    val date: String,
    val hour: String,
    val description: String = "",
    val importancia: Importancia = Importancia.MEDIA,
    val etiqueta: String = "Geral",
    var done: Boolean = false
)

val reminders = mutableStateListOf(
    Reminder("Compras", "29/04/2026", "13:00", "Comprar pão e leite", Importancia.BAIXA, "Pessoal"),
    Reminder("Lavar o Carro", "10/05/2026", "14:00", "Lavar e aspirar o carro", Importancia.MEDIA, "Pessoal")
)

fun corImportancia(importancia: Importancia): Color {
    return when (importancia) {
        Importancia.BAIXA -> Color(0xFF4CAF50)
        Importancia.MEDIA -> Color(0xFFFFC107)
        Importancia.ALTA  -> Color(0xFFF44336)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController) {
    var pesquisaAtiva by remember { mutableStateOf(false) }
    var textoPesquisa by remember { mutableStateOf("") }
    var filtroImportancia by remember { mutableStateOf<Importancia?>(null) }
    var filtroEtiqueta by remember { mutableStateOf<String?>(null) }

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(mensagemSnackbar) {
        mensagemSnackbar?.let {
            scope.launch {
                snackbarHostState.showSnackbar(it)
            }
            mensagemSnackbar = null
        }
    }

    val etiquetasDisponiveis = reminders.map { it.etiqueta }.distinct()

    val remindersFiltrados = reminders.filter { reminder ->
        val matchPesquisa = textoPesquisa.isBlank() ||
                reminder.title.contains(textoPesquisa, ignoreCase = true) ||
                reminder.description.contains(textoPesquisa, ignoreCase = true) ||
                reminder.etiqueta.contains(textoPesquisa, ignoreCase = true)

        val matchImportancia = filtroImportancia == null || reminder.importancia == filtroImportancia
        val matchEtiqueta = filtroEtiqueta == null || reminder.etiqueta == filtroEtiqueta

        matchPesquisa && matchImportancia && matchEtiqueta
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    if (pesquisaAtiva) {
                        OutlinedTextField(
                            value = textoPesquisa,
                            onValueChange = { textoPesquisa = it },
                            placeholder = { Text("Pesquisar...") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Text("Reminder App", fontWeight = FontWeight.Bold)
                    }
                },
                actions = {
                    if (pesquisaAtiva) {
                        IconButton(onClick = {
                            pesquisaAtiva = false
                            textoPesquisa = ""
                        }) {
                            Icon(Icons.Default.Close, contentDescription = "Fechar pesquisa")
                        }
                    } else {
                        IconButton(onClick = { pesquisaAtiva = true }) {
                            Icon(Icons.Default.Search, contentDescription = "Pesquisar")
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { navController.navigate("create") }) {
                Icon(Icons.Default.Add, contentDescription = "Novo lembrete")
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = true,
                    onClick = { },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { navController.navigate("calendar") },
                    icon = { Icon(Icons.Default.DateRange, contentDescription = "Calendário") },
                    label = { Text("Calendário") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { navController.navigate("settings") },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Definições") },
                    label = { Text("Definições") }
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Text(
                text = "Importância",
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(start = 16.dp, top = 8.dp)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    Triple(null, "Todas", Color.Gray),
                    Triple(Importancia.BAIXA, "Baixa", Color(0xFF4CAF50)),
                    Triple(Importancia.MEDIA, "Média", Color(0xFFFFC107)),
                    Triple(Importancia.ALTA, "Alta", Color(0xFFF44336))
                ).forEach { (nivel, label, cor) ->
                    FilterChip(
                        selected = filtroImportancia == nivel,
                        onClick = { filtroImportancia = nivel },
                        label = { Text(label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = cor,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            Text(
                text = "Etiqueta",
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(start = 16.dp, top = 4.dp)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = filtroEtiqueta == null,
                    onClick = { filtroEtiqueta = null },
                    label = { Text("Todas") }
                )
                etiquetasDisponiveis.forEach { etiqueta ->
                    FilterChip(
                        selected = filtroEtiqueta == etiqueta,
                        onClick = {
                            filtroEtiqueta = if (filtroEtiqueta == etiqueta) null else etiqueta
                        },
                        label = { Text(etiqueta) }
                    )
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
            ) {
                itemsIndexed(remindersFiltrados) { _, reminder ->
                    val realIndex = reminders.indexOf(reminder)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .clickable { navController.navigate("detail/$realIndex") },
                        elevation = CardDefaults.cardElevation(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(6.dp)
                                    .height(80.dp)
                                    .background(
                                        color = corImportancia(reminder.importancia),
                                        shape = RoundedCornerShape(topStart = 12.dp, bottomStart = 12.dp)
                                    )
                            )
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = reminder.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Data: ${reminder.date} - Hora: ${reminder.hour}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = reminder.etiqueta,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Checkbox(
                                checked = reminder.done,
                                onCheckedChange = { reminders[realIndex] = reminder.copy(done = it) },
                                modifier = Modifier.padding(end = 8.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}