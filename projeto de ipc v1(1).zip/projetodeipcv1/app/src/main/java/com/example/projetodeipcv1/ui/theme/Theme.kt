package com.example.projetodeipcv1.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import com.example.projetodeipcv1.ui.AppSettings

private val DarkColorScheme = darkColorScheme(
    primary = Purple80,
    secondary = PurpleGrey80,
    tertiary = Pink80
)

private val LightColorScheme = lightColorScheme(
    primary = Purple40,
    secondary = PurpleGrey40,
    tertiary = Pink40

    /* Other default colors to override
    background = Color(0xFFFFFBFE),
    surface = Color(0xFFFFFBFE),
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = Color(0xFF1C1B1F),
    onSurface = Color(0xFF1C1B1F),
    */
)

@Composable
fun ProjetoDeIPCV1Theme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    val escala = AppSettings.fontScale.floatValue
    val typographyEscalada = Typography.copy(
        bodyLarge = Typography.bodyLarge.copy(fontSize = Typography.bodyLarge.fontSize * escala),
        bodyMedium = Typography.bodyMedium.copy(fontSize = Typography.bodyMedium.fontSize * escala),
        bodySmall = Typography.bodySmall.copy(fontSize = Typography.bodySmall.fontSize * escala),
        titleLarge = Typography.titleLarge.copy(fontSize = Typography.titleLarge.fontSize * escala),
        titleMedium = Typography.titleMedium.copy(fontSize = Typography.titleMedium.fontSize * escala),
        labelLarge = Typography.labelLarge.copy(fontSize = Typography.labelLarge.fontSize * escala),
        labelMedium = Typography.labelMedium.copy(fontSize = Typography.labelMedium.fontSize * escala),
        labelSmall = Typography.labelSmall.copy(fontSize = Typography.labelSmall.fontSize * escala)
    )

    MaterialTheme(
        colorScheme = colorScheme,
        typography = typographyEscalada,
        content = content
    )
}