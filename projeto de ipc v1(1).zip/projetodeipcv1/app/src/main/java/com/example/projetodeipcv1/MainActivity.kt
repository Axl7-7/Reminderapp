package com.example.projetodeipcv1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.projetodeipcv1.ui.theme.ProjetoDeIPCV1Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProjetoDeIPCV1Theme {
                AppNavigation()
            }
        }
    }
}