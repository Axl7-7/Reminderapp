package com.example.projetodeipcv1.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarScreen(navController: NavController) {
    val hoje = Calendar.getInstance()
    var mesAtual by remember { mutableStateOf(hoje.get(Calendar.MONTH)) }
    var anoAtual by remember { mutableStateOf(hoje.get(Calendar.YEAR)) }
    var diaSelecionado by remember { mutableStateOf<Int?>(null) }

    val diasDoMes = getDiasDoMes(mesAtual, anoAtual)
    val primeiroDiaSemana = getPrimeiroDiaSemana(mesAtual, anoAtual)
    val nomesMeses = listOf("Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
        "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro")
    val diasSemana = listOf("Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb")

    val lembretesDoMes = reminders.filter { reminder ->
        val partes = reminder.date.split("/")
        if (partes.size == 3) {
            partes[1].toIntOrNull()?.minus(1) == mesAtual &&
                    partes[2].toIntOrNull() == anoAtual
        } else false
    }

    val lembretesDodia = if (diaSelecionado != null) {
        lembretesDoMes.filter { reminder ->
            reminder.date.split("/")[0].toIntOrNull() == diaSelecionado
        }
    } else emptyList()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Calendário") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            // Navegação de mês
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = {
                    if (mesAtual == 0) { mesAtual = 11; anoAtual-- }
                    else mesAtual--
                    diaSelecionado = null
                }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Mês anterior")
                }
                Text(
                    text = "${nomesMeses[mesAtual]} $anoAtual",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = {
                    if (mesAtual == 11) { mesAtual = 0; anoAtual++ }
                    else mesAtual++
                    diaSelecionado = null
                }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Próximo mês")
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Cabeçalho dias da semana
            Row(modifier = Modifier.fillMaxWidth()) {
                diasSemana.forEach { dia ->
                    Text(
                        text = dia,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Grid do calendário
            val totalCelulas = primeiroDiaSemana + diasDoMes
            val linhas = (totalCelulas + 6) / 7

            for (linha in 0 until linhas) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    for (col in 0 until 7) {
                        val celula = linha * 7 + col
                        val dia = celula - primeiroDiaSemana + 1

                        if (dia < 1 || dia > diasDoMes) {
                            Box(modifier = Modifier.weight(1f).height(44.dp))
                        } else {
                            val temLembrete = lembretesDoMes.any { reminder ->
                                reminder.date.split("/")[0].toIntOrNull() == dia
                            }
                            val selecionado = diaSelecionado == dia
                            val eHoje = dia == hoje.get(Calendar.DAY_OF_MONTH) &&
                                    mesAtual == hoje.get(Calendar.MONTH) &&
                                    anoAtual == hoje.get(Calendar.YEAR)

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .padding(2.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when {
                                            selecionado -> MaterialTheme.colorScheme.primary
                                            eHoje -> MaterialTheme.colorScheme.primaryContainer
                                            else -> Color.Transparent
                                        }
                                    )
                                    .clickable { diaSelecionado = dia },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "$dia",
                                        color = when {
                                            selecionado -> Color.White
                                            else -> MaterialTheme.colorScheme.onSurface
                                        },
                                        fontWeight = if (eHoje) FontWeight.Bold else FontWeight.Normal
                                    )
                                    if (temLembrete) {
                                        Box(
                                            modifier = Modifier
                                                .size(5.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    if (selecionado) Color.White
                                                    else MaterialTheme.colorScheme.primary
                                                )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

            // Lembretes do dia selecionado
            if (diaSelecionado != null) {
                Text(
                    text = if (lembretesDodia.isEmpty()) "Sem lembretes para este dia"
                    else "Lembretes de ${diaSelecionado}/${mesAtual + 1}/$anoAtual",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(lembretesDodia) { reminder ->
                        val realIndex = reminders.indexOf(reminder)
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { navController.navigate("detail/$realIndex") },
                            elevation = CardDefaults.cardElevation(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .width(6.dp)
                                        .height(60.dp)
                                        .background(
                                            color = corImportancia(reminder.importancia),
                                            shape = RoundedCornerShape(topStart = 12.dp, bottomStart = 12.dp)
                                        )
                                )
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = reminder.title,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyLarge
                                    )
                                    Text(
                                        text = "Hora: ${reminder.hour}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                Text(
                    text = "Seleciona um dia para ver os lembretes",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

fun getDiasDoMes(mes: Int, ano: Int): Int {
    val cal = Calendar.getInstance()
    cal.set(ano, mes, 1)
    return cal.getActualMaximum(Calendar.DAY_OF_MONTH)
}

fun getPrimeiroDiaSemana(mes: Int, ano: Int): Int {
    val cal = Calendar.getInstance()
    cal.set(ano, mes, 1)
    return cal.get(Calendar.DAY_OF_WEEK) - 1
}