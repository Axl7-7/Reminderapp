package com.example.projetodeipcv1.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object AppSettings {
    val fontScale = mutableFloatStateOf(1f)
}

val deletedReminders = mutableStateListOf<Reminder>()
var mensagemSnackbar by mutableStateOf<String?>(null)