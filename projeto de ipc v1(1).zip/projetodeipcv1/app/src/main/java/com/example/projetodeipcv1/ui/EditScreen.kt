package com.example.projetodeipcv1.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditScreen(navController: NavController, index: Int) {
    val context = LocalContext.current
    val calendar = Calendar.getInstance()
    val reminder = reminders.getOrNull(index) ?: return

    var title by remember { mutableStateOf(reminder.title) }
    var date by remember { mutableStateOf(reminder.date) }
    var hour by remember { mutableStateOf(reminder.hour) }
    var description by remember { mutableStateOf(reminder.description) }
    var importancia by remember { mutableStateOf(reminder.importancia) }
    var etiquetaSelecionada by remember { mutableStateOf(reminder.etiqueta) }
    var etiquetaExpanded by remember { mutableStateOf(false) }
    var titleError by remember { mutableStateOf(false) }

    val datePickerDialog = DatePickerDialog(
        context,
        { _, year, month, day ->
            date = "%02d/%02d/%04d".format(day, month + 1, year)
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    )

    val timePickerDialog = TimePickerDialog(
        context,
        { _, hourOfDay, minute ->
            hour = "%02d:%02d".format(hourOfDay, minute)
        },
        calendar.get(Calendar.HOUR_OF_DAY),
        calendar.get(Calendar.MINUTE),
        true
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Editar Lembrete") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it; titleError = false },
                label = { Text("Título *") },
                isError = titleError,
                supportingText = { if (titleError) Text("O título é obrigatório") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Descrição") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = { datePickerDialog.show() },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                )
            ) {
                Text("Data: $date")
            }

            Button(
                onClick = { timePickerDialog.show() },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                )
            ) {
                Text("Hora: $hour")
            }

            Text("Nível de Importância", style = MaterialTheme.typography.labelLarge)
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                listOf(
                    Triple(Importancia.BAIXA, "Baixa", Color(0xFF4CAF50)),
                    Triple(Importancia.MEDIA, "Média", Color(0xFFFFC107)),
                    Triple(Importancia.ALTA, "Alta", Color(0xFFF44336))
                ).forEach { (nivel, label, cor) ->
                    FilterChip(
                        selected = importancia == nivel,
                        onClick = { importancia = nivel },
                        label = { Text(label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = cor,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Text("Etiqueta", style = MaterialTheme.typography.labelLarge)
            ExposedDropdownMenuBox(
                expanded = etiquetaExpanded,
                onExpandedChange = { etiquetaExpanded = it }
            ) {
                OutlinedTextField(
                    value = etiquetaSelecionada,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Categoria") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = etiquetaExpanded) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = etiquetaExpanded,
                    onDismissRequest = { etiquetaExpanded = false }
                ) {
                    listOf("Geral", "Pessoal", "Trabalho", "Saúde", "Escola").forEach { etiqueta ->
                        DropdownMenuItem(
                            text = { Text(etiqueta) },
                            onClick = {
                                etiquetaSelecionada = etiqueta
                                etiquetaExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    titleError = title.isBlank()
                    if (!titleError) {
                        reminders[index] = Reminder(
                            title = title,
                            date = date,
                            hour = hour,
                            description = description,
                            importancia = importancia,
                            etiqueta = etiquetaSelecionada,
                            done = reminder.done
                        )
                        navController.popBackStack()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Guardar Alterações")
            }
        }
    }
}

