package com.example.reminderapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TrashAdapter(
    private val trashList: MutableList<Reminder>
) : RecyclerView.Adapter<TrashAdapter.TrashViewHolder>() {

    private val selectedPositions = mutableSetOf<Int>()

    class TrashViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txtTrashTitle: TextView = itemView.findViewById(R.id.txtTrashTitle)
        val txtTrashDateTime: TextView = itemView.findViewById(R.id.txtTrashDateTime)
        val checkTrash: CheckBox = itemView.findViewById(R.id.checkTrash)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TrashViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_trash_reminder, parent, false)
        return TrashViewHolder(view)
    }

    override fun onBindViewHolder(holder: TrashViewHolder, position: Int) {
        val reminder = trashList[position]

        holder.txtTrashTitle.text = reminder.title
        holder.txtTrashDateTime.text = "Data: ${reminder.date} - Hora: ${reminder.time}"

        holder.checkTrash.setOnCheckedChangeListener(null)
        holder.checkTrash.isChecked = selectedPositions.contains(position)

        holder.checkTrash.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                selectedPositions.add(position)
            } else {
                selectedPositions.remove(position)
            }
        }
    }

    override fun getItemCount(): Int = trashList.size

    fun getSelectedPositions(): Set<Int> {
        return selectedPositions
    }
}