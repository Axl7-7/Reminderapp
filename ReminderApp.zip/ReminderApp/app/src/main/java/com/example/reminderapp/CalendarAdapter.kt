package com.example.reminderapp

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CalendarAdapter(
    private val daysList: List<String>,
    private val currentMonth: Int,
    private val currentYear: Int,
    private val reminderDates: Set<String>,
    private val selectedDate: String?,
    private val onDayClick: (String) -> Unit
) : RecyclerView.Adapter<CalendarAdapter.DayViewHolder>() {

    class DayViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txtDay: TextView = itemView.findViewById(R.id.txtDay)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DayViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_calendar_day, parent, false)
        return DayViewHolder(view)
    }

    override fun onBindViewHolder(holder: DayViewHolder, position: Int) {
        val dayText = daysList[position]
        holder.txtDay.text = dayText

        if (dayText.isBlank()) {
            holder.txtDay.setBackgroundColor(Color.TRANSPARENT)
            holder.txtDay.setTextColor(Color.TRANSPARENT)
            holder.txtDay.setOnClickListener(null)
            return
        }

        val formattedDay = String.format("%02d", dayText.toInt())
        val formattedMonth = String.format("%02d", currentMonth + 1)
        val fullDate = "$formattedDay/$formattedMonth/$currentYear"

        when {
            fullDate == selectedDate -> {
                holder.txtDay.setBackgroundColor(Color.parseColor("#66BB6A"))
                holder.txtDay.setTextColor(Color.WHITE)
            }
            reminderDates.contains(fullDate) -> {
                holder.txtDay.setBackgroundColor(Color.parseColor("#C8E6C9"))
                holder.txtDay.setTextColor(Color.BLACK)
            }
            else -> {
                holder.txtDay.setBackgroundColor(Color.WHITE)
                holder.txtDay.setTextColor(Color.BLACK)
            }
        }

        holder.txtDay.setOnClickListener {
            onDayClick(fullDate)
        }
    }

    override fun getItemCount(): Int = daysList.size
}