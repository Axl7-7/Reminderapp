package com.example.reminderapp

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ReminderDetailActivity : AppCompatActivity() {

    private var reminderIndex: Int = -1
    private lateinit var reminderList: MutableList<Reminder>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reminder_detail)

        val btnBackDetail = findViewById<Button>(R.id.btnBackDetail)
        val txtTitleValue = findViewById<TextView>(R.id.txtTitleValue)
        val txtDescriptionValue = findViewById<TextView>(R.id.txtDescriptionValue)
        val txtDateValue = findViewById<TextView>(R.id.txtDateValue)
        val txtTimeValue = findViewById<TextView>(R.id.txtTimeValue)
        val txtPriorityValue = findViewById<TextView>(R.id.txtPriorityValue)
        val txtCategoryValue = findViewById<TextView>(R.id.txtCategoryValue)
        val txtCompletedStatus = findViewById<TextView>(R.id.txtCompletedStatus)
        val viewPriorityColor = findViewById<View>(R.id.viewPriorityColor)

        val btnEdit = findViewById<Button>(R.id.btnEdit)
        val btnComplete = findViewById<Button>(R.id.btnComplete)
        val btnDelete = findViewById<Button>(R.id.btnDelete)

        reminderList = ReminderStorage.loadReminders(this)
        reminderIndex = intent.getIntExtra("reminderIndex", -1)

        if (reminderIndex == -1 || reminderIndex >= reminderList.size) {
            finish()
            return
        }

        fun refreshUI() {
            val reminder = reminderList[reminderIndex]

            txtTitleValue.text = reminder.title
            txtDescriptionValue.text = reminder.description
            txtDateValue.text = reminder.date
            txtTimeValue.text = reminder.time
            txtPriorityValue.text = reminder.priority
            txtCategoryValue.text = reminder.category
            txtCompletedStatus.text = if (reminder.completed) "Concluído" else "Pendente"
            btnComplete.text = if (reminder.completed) "Marcar pendente" else "Marcar concluído"

            try {
                viewPriorityColor.setBackgroundColor(Color.parseColor(reminder.color))
            } catch (_: Exception) {
                viewPriorityColor.setBackgroundColor(Color.GRAY)
            }
        }

        refreshUI()

        btnBackDetail.setOnClickListener {
            finish()
        }

        btnEdit.setOnClickListener {
            val reminder = reminderList[reminderIndex]

            val editIntent = Intent(this, CreateReminderActivity::class.java)
            editIntent.putExtra("isEditing", true)
            editIntent.putExtra("reminderIndex", reminderIndex)
            editIntent.putExtra("title", reminder.title)
            editIntent.putExtra("description", reminder.description)
            editIntent.putExtra("date", reminder.date)
            editIntent.putExtra("time", reminder.time)
            editIntent.putExtra("priority", reminder.priority)
            editIntent.putExtra("color", reminder.color)
            editIntent.putExtra("category", reminder.category)
            startActivity(editIntent)
            finish()
        }

        btnComplete.setOnClickListener {
            reminderList[reminderIndex].completed = !reminderList[reminderIndex].completed
            ReminderStorage.saveReminders(this, reminderList)
            refreshUI()
        }

        btnDelete.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Apagar lembrete")
                .setMessage("Tens a certeza que queres mover este lembrete para os apagados?")
                .setPositiveButton("Sim") { _, _ ->
                    reminderList[reminderIndex].deleted = true
                    ReminderStorage.saveReminders(this, reminderList)
                    finish()
                }
                .setNegativeButton("Não", null)
                .show()
        }
    }
}