package com.example.reminderapp

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

class SettingsActivity : AppCompatActivity() {

    private lateinit var btnBackSettings: Button
    private lateinit var switchDarkMode: SwitchCompat
    private lateinit var switchNotifications: SwitchCompat
    private lateinit var switchSound: SwitchCompat
    private lateinit var switchVibration: SwitchCompat
    private lateinit var btnRestoreDeleted: Button
    private lateinit var btnDeleteAll: Button

    private val prefsName = "app_settings"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        btnBackSettings = findViewById(R.id.btnBackSettings)
        switchDarkMode = findViewById(R.id.switchDarkMode)
        switchNotifications = findViewById(R.id.switchNotifications)
        switchSound = findViewById(R.id.switchSound)
        switchVibration = findViewById(R.id.switchVibration)
        btnRestoreDeleted = findViewById(R.id.btnRestoreDeleted)
        btnDeleteAll = findViewById(R.id.btnDeleteAll)

        val prefs = getSharedPreferences(prefsName, MODE_PRIVATE)

        switchDarkMode.isChecked = prefs.getBoolean("dark_mode", false)
        switchNotifications.isChecked = prefs.getBoolean("notifications", true)
        switchSound.isChecked = prefs.getBoolean("sound", true)
        switchVibration.isChecked = prefs.getBoolean("vibration", true)

        btnBackSettings.setOnClickListener {
            finish()
        }

        switchDarkMode.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("dark_mode", isChecked).apply()
            Toast.makeText(this, "Modo escuro atualizado", Toast.LENGTH_SHORT).show()
        }

        switchNotifications.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("notifications", isChecked).apply()
        }

        switchSound.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("sound", isChecked).apply()
        }

        switchVibration.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("vibration", isChecked).apply()
        }

        btnRestoreDeleted.setOnClickListener {
            startActivity(Intent(this, TrashActivity::class.java))
        }

        btnDeleteAll.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Apagar todos os lembretes")
                .setMessage("Tens a certeza que queres apagar todos os lembretes?")
                .setPositiveButton("Sim") { _, _ ->
                    ReminderStorage.saveReminders(this, mutableListOf())
                    Toast.makeText(this, "Todos os lembretes foram apagados", Toast.LENGTH_SHORT).show()
                    finish()
                }
                .setNegativeButton("Não", null)
                .show()
        }
    }
}