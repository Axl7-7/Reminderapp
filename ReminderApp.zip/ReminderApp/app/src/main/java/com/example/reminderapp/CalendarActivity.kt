package com.example.reminderapp

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class CalendarActivity : AppCompatActivity() {

    private lateinit var btnBackCalendar: Button
    private lateinit var btnPreviousMonth: Button
    private lateinit var btnNextMonth: Button
    private lateinit var txtMonthYear: TextView
    private lateinit var txtSelectedDate: TextView
    private lateinit var recyclerCalendar: RecyclerView
    private lateinit var recyclerDayTasks: RecyclerView

    private lateinit var calendarAdapter: CalendarAdapter
    private lateinit var dayTasksAdapter: ReminderAdapter

    private val calendar = Calendar.getInstance()
    private lateinit var reminderList: MutableList<Reminder>

    private var selectedDate: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calendar)

        btnBackCalendar = findViewById(R.id.btnBackCalendar)
        btnPreviousMonth = findViewById(R.id.btnPreviousMonth)
        btnNextMonth = findViewById(R.id.btnNextMonth)
        txtMonthYear = findViewById(R.id.txtMonthYear)
        txtSelectedDate = findViewById(R.id.txtSelectedDate)
        recyclerCalendar = findViewById(R.id.recyclerCalendar)
        recyclerDayTasks = findViewById(R.id.recyclerDayTasks)

        reminderList = ReminderStorage.loadReminders(this)

        recyclerCalendar.layoutManager = GridLayoutManager(this, 7)
        recyclerDayTasks.layoutManager = LinearLayoutManager(this)

        btnBackCalendar.setOnClickListener {
            finish()
        }

        btnPreviousMonth.setOnClickListener {
            calendar.add(Calendar.MONTH, -1)
            selectedDate = null
            loadCalendar()
            showTasksForSelectedDate()
        }

        btnNextMonth.setOnClickListener {
            calendar.add(Calendar.MONTH, 1)
            selectedDate = null
            loadCalendar()
            showTasksForSelectedDate()
        }

        loadCalendar()
        showTasksForSelectedDate()
    }

    private fun loadCalendar() {
        val monthFormat = SimpleDateFormat("MMMM yyyy", Locale("pt", "PT"))
        txtMonthYear.text = monthFormat.format(calendar.time)

        val daysList = mutableListOf<String>()

        val monthCalendar = calendar.clone() as Calendar
        monthCalendar.set(Calendar.DAY_OF_MONTH, 1)

        val firstDayOfWeek = monthCalendar.get(Calendar.DAY_OF_WEEK)
        val daysInMonth = monthCalendar.getActualMaximum(Calendar.DAY_OF_MONTH)

        val startOffset = if (firstDayOfWeek == Calendar.SUNDAY) 6 else firstDayOfWeek - 2

        for (i in 0 until startOffset) {
            daysList.add("")
        }

        for (day in 1..daysInMonth) {
            daysList.add(day.toString())
        }

        val reminderDates = reminderList.map { it.date }.toSet()

        calendarAdapter = CalendarAdapter(
            daysList = daysList,
            currentMonth = calendar.get(Calendar.MONTH),
            currentYear = calendar.get(Calendar.YEAR),
            reminderDates = reminderDates,
            selectedDate = selectedDate,
            onDayClick = { clickedDate ->
                selectedDate = clickedDate
                loadCalendar()
                showTasksForSelectedDate()
            }
        )

        recyclerCalendar.adapter = calendarAdapter
    }

    private fun showTasksForSelectedDate() {
        val filteredList = if (selectedDate == null) {
            mutableListOf()
        } else {
            reminderList.filter { it.date == selectedDate }.toMutableList()
        }

        txtSelectedDate.text = if (selectedDate == null) {
            "Tarefas do dia:"
        } else {
            "Tarefas de $selectedDate"
        }

        dayTasksAdapter = ReminderAdapter(filteredList)
        recyclerDayTasks.adapter = dayTasksAdapter
    }
}