package com.example.reminderapp

import android.app.AlertDialog
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class TrashActivity : AppCompatActivity() {

    private lateinit var recyclerTrash: RecyclerView
    private lateinit var btnBackTrash: Button
    private lateinit var btnRestoreSelected: Button
    private lateinit var btnDeleteSelected: Button

    private lateinit var trashList: MutableList<Reminder>
    private lateinit var allReminders: MutableList<Reminder>
    private lateinit var adapter: TrashAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trash)

        recyclerTrash = findViewById(R.id.recyclerTrash)
        btnBackTrash = findViewById(R.id.btnBackTrash)
        btnRestoreSelected = findViewById(R.id.btnRestoreSelected)
        btnDeleteSelected = findViewById(R.id.btnDeleteSelected)

        allReminders = ReminderStorage.loadReminders(this)
        trashList = allReminders.filter { it.deleted }.toMutableList()

        adapter = TrashAdapter(trashList)
        recyclerTrash.layoutManager = LinearLayoutManager(this)
        recyclerTrash.adapter = adapter

        btnBackTrash.setOnClickListener {
            finish()
        }

        btnRestoreSelected.setOnClickListener {
            val selected = adapter.getSelectedPositions().sortedDescending()

            if (selected.isEmpty()) {
                Toast.makeText(this, "Seleciona pelo menos um lembrete", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            for (position in selected) {
                val trashReminder = trashList[position]
                val original = allReminders.find {
                    it.title == trashReminder.title &&
                            it.description == trashReminder.description &&
                            it.date == trashReminder.date &&
                            it.time == trashReminder.time &&
                            it.deleted
                }
                original?.deleted = false
            }

            ReminderStorage.saveReminders(this, allReminders)
            Toast.makeText(this, "Lembretes recuperados", Toast.LENGTH_SHORT).show()
            finish()
        }

        btnDeleteSelected.setOnClickListener {
            val selected = adapter.getSelectedPositions().sortedDescending()

            if (selected.isEmpty()) {
                Toast.makeText(this, "Seleciona pelo menos um lembrete", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            AlertDialog.Builder(this)
                .setTitle("Apagar definitivamente")
                .setMessage("Tens a certeza que queres apagar os lembretes selecionados?")
                .setPositiveButton("Sim") { _, _ ->
                    val selectedReminders = selected.map { trashList[it] }

                    allReminders.removeAll { reminder ->
                        selectedReminders.any {
                            it.title == reminder.title &&
                                    it.description == reminder.description &&
                                    it.date == reminder.date &&
                                    it.time == reminder.time &&
                                    reminder.deleted
                        }
                    }

                    ReminderStorage.saveReminders(this, allReminders)
                    Toast.makeText(this, "Lembretes apagados definitivamente", Toast.LENGTH_SHORT).show()
                    finish()
                }
                .setNegativeButton("Não", null)
                .show()
        }
    }
}