package com.example.reminderapp

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object ReminderStorage {

    private const val PREFS_NAME = "reminder_prefs"
    private const val KEY_REMINDERS = "reminders"

    fun saveReminders(context: Context, reminders: MutableList<Reminder>) {
        val sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val json = Gson().toJson(reminders)
        editor.putString(KEY_REMINDERS, json)
        editor.apply()
    }

    fun loadReminders(context: Context): MutableList<Reminder> {
        val sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = sharedPreferences.getString(KEY_REMINDERS, null)

        return if (json != null) {
            val type = object : TypeToken<MutableList<Reminder>>() {}.type
            Gson().fromJson(json, type)
        } else {
            mutableListOf()
        }
    }
}