package com.example.reminderapp

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.os.Bundle
import android.text.InputType
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar

class CreateReminderActivity : AppCompatActivity() {

    private lateinit var btnBackCreate: Button
    private lateinit var txtCreateTitle: TextView
    private lateinit var etTitle: EditText
    private lateinit var etDescription: EditText
    private lateinit var etDate: EditText
    private lateinit var etTime: EditText
    private lateinit var spinnerCategory: Spinner
    private lateinit var radioGroupPriority: RadioGroup
    private lateinit var btnSaveReminder: Button

    private lateinit var reminderList: MutableList<Reminder>
    private lateinit var categoryAdapter: ArrayAdapter<String>

    private var isEditing = false
    private var reminderIndex = -1

    private var selectedPriority = "Alta"
    private var selectedColor = "#F44336"
    private var selectedCategory = "Pessoal"

    private val defaultCategories = listOf(
        "Pessoal",
        "Trabalho",
        "Estudo",
        "Saúde",
        "Compras"
    )

    private val addCategoryOption = "+ Nova categoria"
    private val manageCategoriesOption = "Gerir categorias"
    private val sharedPrefsName = "reminder_prefs"
    private val categoriesKey = "custom_categories"

    private val categories = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_reminder)

        btnBackCreate = findViewById(R.id.btnBackCreate)
        txtCreateTitle = findViewById(R.id.txtCreateTitle)
        etTitle = findViewById(R.id.etTitle)
        etDescription = findViewById(R.id.etDescription)
        etDate = findViewById(R.id.etDate)
        etTime = findViewById(R.id.etTime)
        spinnerCategory = findViewById(R.id.spinnerCategory)
        radioGroupPriority = findViewById(R.id.radioGroupPriority)
        btnSaveReminder = findViewById(R.id.btnSaveReminder)

        reminderList = ReminderStorage.loadReminders(this)

        loadCategories()
        setupCategorySpinner()

        isEditing = intent.getBooleanExtra("isEditing", false)
        reminderIndex = intent.getIntExtra("reminderIndex", -1)

        if (isEditing) {
            txtCreateTitle.text = "Editar lembrete"
            btnSaveReminder.text = "Atualizar"

            etTitle.setText(intent.getStringExtra("title") ?: "")
            etDescription.setText(intent.getStringExtra("description") ?: "")
            etDate.setText(intent.getStringExtra("date") ?: "")
            etTime.setText(intent.getStringExtra("time") ?: "")

            selectedPriority = intent.getStringExtra("priority") ?: "Alta"
            selectedCategory = intent.getStringExtra("category") ?: "Pessoal"
        } else {
            txtCreateTitle.text = "Criar lembrete"
            btnSaveReminder.text = "Guardar"
            selectedPriority = "Alta"
            selectedCategory = "Pessoal"
        }

        if (!categories.contains(selectedCategory)
            && selectedCategory != addCategoryOption
            && selectedCategory != manageCategoriesOption
        ) {
            categories.add(categories.size - 2, selectedCategory)
            saveCustomCategories()
            categoryAdapter.notifyDataSetChanged()
        }

        setSpinnerCategory(selectedCategory)
        updatePrioritySelection(selectedPriority)

        btnBackCreate.setOnClickListener {
            finish()
        }

        etDate.setOnClickListener {
            showDatePicker()
        }

        etTime.setOnClickListener {
            showTimePicker()
        }

        radioGroupPriority.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.radioHigh -> {
                    selectedPriority = "Alta"
                    selectedColor = "#F44336"
                }
                R.id.radioMedium -> {
                    selectedPriority = "Média"
                    selectedColor = "#FF9800"
                }
                R.id.radioLow -> {
                    selectedPriority = "Baixa"
                    selectedColor = "#4CAF50"
                }
            }
        }

        btnSaveReminder.setOnClickListener {
            saveReminder()
        }
    }

    private fun loadCategories() {
        categories.clear()
        categories.addAll(defaultCategories)

        val prefs = getSharedPreferences(sharedPrefsName, Context.MODE_PRIVATE)
        val savedCategoriesString = prefs.getString(categoriesKey, "") ?: ""

        if (savedCategoriesString.isNotEmpty()) {
            val savedCategories = savedCategoriesString.split("||")
                .map { it.trim() }
                .filter { it.isNotEmpty() }

            for (category in savedCategories) {
                if (!categories.contains(category)) {
                    categories.add(category)
                }
            }
        }

        categories.add(addCategoryOption)
        categories.add(manageCategoriesOption)
    }

    private fun saveCustomCategories() {
        val prefs = getSharedPreferences(sharedPrefsName, Context.MODE_PRIVATE)

        val customCategories = categories.filter {
            it !in defaultCategories &&
                    it != addCategoryOption &&
                    it != manageCategoriesOption
        }

        prefs.edit()
            .putString(categoriesKey, customCategories.joinToString("||"))
            .apply()
    }

    private fun setupCategorySpinner() {
        categoryAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            categories
        )
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCategory.adapter = categoryAdapter

        spinnerCategory.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            private var isFirstSelection = true

            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                val selectedItem = categories[position]

                if (isFirstSelection) {
                    isFirstSelection = false
                    return
                }

                when (selectedItem) {
                    addCategoryOption -> showAddCategoryDialog()
                    manageCategoriesOption -> showManageCategoriesDialog()
                    else -> selectedCategory = selectedItem
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }
    }

    private fun showAddCategoryDialog() {
        val input = EditText(this)
        input.hint = "Nome da nova categoria"
        input.inputType = InputType.TYPE_CLASS_TEXT

        AlertDialog.Builder(this)
            .setTitle("Criar categoria")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                val newCategory = input.text.toString().trim()

                if (newCategory.isEmpty()) {
                    Toast.makeText(this, "Escreve um nome para a categoria", Toast.LENGTH_SHORT).show()
                    setSpinnerCategory(selectedCategory)
                    return@setPositiveButton
                }

                if (categories.any { it.equals(newCategory, ignoreCase = true) }) {
                    Toast.makeText(this, "Essa categoria já existe", Toast.LENGTH_SHORT).show()
                    setSpinnerCategory(selectedCategory)
                    return@setPositiveButton
                }

                categories.add(categories.size - 2, newCategory)
                saveCustomCategories()
                categoryAdapter.notifyDataSetChanged()

                selectedCategory = newCategory
                setSpinnerCategory(newCategory)

                Toast.makeText(this, "Categoria criada com sucesso", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
                setSpinnerCategory(selectedCategory)
            }
            .setOnCancelListener {
                setSpinnerCategory(selectedCategory)
            }
            .show()
    }

    private fun showManageCategoriesDialog() {
        val customCategories = categories.filter {
            it !in defaultCategories &&
                    it != addCategoryOption &&
                    it != manageCategoriesOption
        }

        if (customCategories.isEmpty()) {
            Toast.makeText(this, "Não há categorias personalizadas para apagar", Toast.LENGTH_SHORT).show()
            setSpinnerCategory(selectedCategory)
            return
        }

        val categoriesArray = customCategories.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Apagar categoria")
            .setItems(categoriesArray) { _, which ->
                val categoryToDelete = categoriesArray[which]
                showDeleteCategoryConfirmation(categoryToDelete)
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
                setSpinnerCategory(selectedCategory)
            }
            .setOnCancelListener {
                setSpinnerCategory(selectedCategory)
            }
            .show()
    }

    private fun showDeleteCategoryConfirmation(categoryToDelete: String) {
        AlertDialog.Builder(this)
            .setTitle("Confirmar eliminação")
            .setMessage("Queres apagar a categoria \"$categoryToDelete\"? Os lembretes dessa categoria passarão para \"Pessoal\".")
            .setPositiveButton("Apagar") { _, _ ->
                deleteCategory(categoryToDelete)
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
                setSpinnerCategory(selectedCategory)
            }
            .setOnCancelListener {
                setSpinnerCategory(selectedCategory)
            }
            .show()
    }

    private fun deleteCategory(categoryToDelete: String) {
        categories.remove(categoryToDelete)
        saveCustomCategories()

        reminderList.forEach { reminder ->
            if (reminder.category.equals(categoryToDelete, ignoreCase = true)) {
                reminder.category = "Pessoal"
            }
        }

        ReminderStorage.saveReminders(this, reminderList)

        if (selectedCategory.equals(categoryToDelete, ignoreCase = true)) {
            selectedCategory = "Pessoal"
        }

        categoryAdapter.notifyDataSetChanged()
        setSpinnerCategory(selectedCategory)

        Toast.makeText(this, "Categoria apagada com sucesso", Toast.LENGTH_SHORT).show()
    }

    private fun setSpinnerCategory(category: String) {
        val position = categories.indexOf(category)
        if (position >= 0) {
            spinnerCategory.setSelection(position)
        } else {
            spinnerCategory.setSelection(0)
            selectedCategory = categories[0]
        }
    }

    private fun updatePrioritySelection(priority: String) {
        when (priority) {
            "Alta" -> {
                radioGroupPriority.check(R.id.radioHigh)
                selectedPriority = "Alta"
                selectedColor = "#F44336"
            }
            "Média" -> {
                radioGroupPriority.check(R.id.radioMedium)
                selectedPriority = "Média"
                selectedColor = "#FF9800"
            }
            "Baixa" -> {
                radioGroupPriority.check(R.id.radioLow)
                selectedPriority = "Baixa"
                selectedColor = "#4CAF50"
            }
            else -> {
                radioGroupPriority.check(R.id.radioHigh)
                selectedPriority = "Alta"
                selectedColor = "#F44336"
            }
        }
    }

    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
            val formattedDate = String.format(
                "%02d/%02d/%04d",
                selectedDay,
                selectedMonth + 1,
                selectedYear
            )
            etDate.setText(formattedDate)
        }, year, month, day).show()
    }

    private fun showTimePicker() {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        TimePickerDialog(this, { _, selectedHour, selectedMinute ->
            val formattedTime = String.format("%02d:%02d", selectedHour, selectedMinute)
            etTime.setText(formattedTime)
        }, hour, minute, true).show()
    }

    private fun saveReminder() {
        val title = etTitle.text.toString().trim()
        val description = etDescription.text.toString().trim()
        val date = etDate.text.toString().trim()
        val time = etTime.text.toString().trim()
        val category = selectedCategory

        if (title.isEmpty() || description.isEmpty() || date.isEmpty() || time.isEmpty()) {
            Toast.makeText(this, "Preenche todos os campos", Toast.LENGTH_SHORT).show()
            return
        }

        if (isEditing && reminderIndex >= 0 && reminderIndex < reminderList.size) {
            val reminder = reminderList[reminderIndex]
            reminder.title = title
            reminder.description = description
            reminder.date = date
            reminder.time = time
            reminder.priority = selectedPriority
            reminder.color = selectedColor
            reminder.category = category
        } else {
            val newReminder = Reminder(
                title = title,
                description = description,
                date = date,
                time = time,
                color = selectedColor,
                priority = selectedPriority,
                completed = false,
                category = category
            )
            reminderList.add(0, newReminder)
        }

        ReminderStorage.saveReminders(this, reminderList)
        setResult(Activity.RESULT_OK)
        finish()
    }
}