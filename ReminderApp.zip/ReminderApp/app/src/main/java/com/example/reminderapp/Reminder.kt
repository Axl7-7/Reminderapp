package com.example.reminderapp

data class Reminder(
    var title: String,
    var description: String,
    var date: String,
    var time: String,
    var color: String,
    var priority: String,
    var completed: Boolean = false,
    var category: String = "Pessoal",
    var deleted: Boolean = false
)