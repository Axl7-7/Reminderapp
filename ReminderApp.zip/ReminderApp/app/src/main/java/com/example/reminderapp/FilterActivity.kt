package com.example.reminderapp

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity

class FilterActivity : AppCompatActivity() {

    private lateinit var btnBackFilter: Button
    private lateinit var btnApplyFilter: Button
    private lateinit var btnClearFilter: Button

    private lateinit var radioGroupStatus: RadioGroup
    private lateinit var radioGroupCategory: RadioGroup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_filter)

        btnBackFilter = findViewById(R.id.btnBackFilter)
        btnApplyFilter = findViewById(R.id.btnApplyFilter)
        btnClearFilter = findViewById(R.id.btnClearFilter)

        radioGroupStatus = findViewById(R.id.radioGroupStatus)
        radioGroupCategory = findViewById(R.id.radioGroupCategory)

        val currentStatusFilter = intent.getStringExtra("statusFilter") ?: "Todos"
        val currentCategoryFilter = intent.getStringExtra("categoryFilter") ?: "Todas"

        when (currentStatusFilter) {
            "Pendentes" -> findViewById<RadioButton>(R.id.radioPending).isChecked = true
            "Concluídos" -> findViewById<RadioButton>(R.id.radioCompleted).isChecked = true
            else -> findViewById<RadioButton>(R.id.radioAll).isChecked = true
        }

        setupDynamicCategories(currentCategoryFilter)

        btnBackFilter.setOnClickListener {
            finish()
        }

        btnApplyFilter.setOnClickListener {
            val selectedStatus = when (radioGroupStatus.checkedRadioButtonId) {
                R.id.radioPending -> "Pendentes"
                R.id.radioCompleted -> "Concluídos"
                else -> "Todos"
            }

            val checkedId = radioGroupCategory.checkedRadioButtonId
            val selectedCategory = if (checkedId != -1) {
                findViewById<RadioButton>(checkedId).text.toString()
            } else {
                "Todas"
            }

            val resultIntent = Intent()
            resultIntent.putExtra("statusFilter", selectedStatus)
            resultIntent.putExtra("categoryFilter", selectedCategory)
            setResult(Activity.RESULT_OK, resultIntent)
            finish()
        }

        btnClearFilter.setOnClickListener {
            val resultIntent = Intent()
            resultIntent.putExtra("statusFilter", "Todos")
            resultIntent.putExtra("categoryFilter", "Todas")
            setResult(Activity.RESULT_OK, resultIntent)
            finish()
        }
    }

    private fun setupDynamicCategories(currentCategoryFilter: String) {
        val reminders = ReminderStorage.loadReminders(this)

        val categories = reminders
            .filter { !it.deleted }
            .map { it.category.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
            .sorted()
            .toMutableList()

        categories.add(0, "Todas")

        radioGroupCategory.removeAllViews()

        categories.forEach { category ->
            val radioButton = RadioButton(this)
            radioButton.id = android.view.View.generateViewId()
            radioButton.layoutParams = RadioGroup.LayoutParams(
                RadioGroup.LayoutParams.WRAP_CONTENT,
                RadioGroup.LayoutParams.WRAP_CONTENT
            )
            radioButton.text = category
            radioButton.textSize = 16f

            radioGroupCategory.addView(radioButton)

            if (category == currentCategoryFilter) {
                radioButton.isChecked = true
            }
        }

        if (radioGroupCategory.checkedRadioButtonId == -1 && radioGroupCategory.childCount > 0) {
            (radioGroupCategory.getChildAt(0) as RadioButton).isChecked = true
        }
    }
}