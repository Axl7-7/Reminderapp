package com.example.reminderapp

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ReminderAdapter
    private lateinit var fabCenterAdd: FloatingActionButton
    private lateinit var btnHome: LinearLayout
    private lateinit var btnCalendar: LinearLayout
    private lateinit var btnSettings: Button

    private lateinit var reminderList: MutableList<Reminder>
    private lateinit var allReminders: MutableList<Reminder>

    private var statusFilter = "Todos"
    private var categoryFilter = "Todas"

    private val createReminderLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                reloadAndApplyFilters()
                recyclerView.scrollToPosition(0)
            }
        }

    private val filterLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                statusFilter = result.data?.getStringExtra("statusFilter") ?: "Todos"
                categoryFilter = result.data?.getStringExtra("categoryFilter") ?: "Todas"
                applyFilters()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        val prefs = getSharedPreferences("app_settings", MODE_PRIVATE)
        val darkModeEnabled = prefs.getBoolean("dark_mode", false)

        if (darkModeEnabled) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerReminders)
        fabCenterAdd = findViewById(R.id.fabCenterAdd)
        btnHome = findViewById(R.id.btnHome)
        btnCalendar = findViewById(R.id.btnCalendar)
        btnSettings = findViewById(R.id.btnSettings)

        allReminders = ReminderStorage.loadReminders(this)
        reminderList = mutableListOf()

        adapter = ReminderAdapter(reminderList)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        applyFilters()

        fabCenterAdd.setOnClickListener {
            val intent = Intent(this, CreateReminderActivity::class.java)
            createReminderLauncher.launch(intent)
        }

        btnHome.setOnClickListener {
            val intent = Intent(this, FilterActivity::class.java)
            intent.putExtra("statusFilter", statusFilter)
            intent.putExtra("categoryFilter", categoryFilter)
            filterLauncher.launch(intent)
        }

        btnCalendar.setOnClickListener {
            startActivity(Intent(this, CalendarActivity::class.java))
        }

        btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        reloadAndApplyFilters()
    }

    private fun reloadAndApplyFilters() {
        allReminders = ReminderStorage.loadReminders(this)
        applyFilters()
    }

    private fun applyFilters() {
        val filteredList = allReminders.filter { reminder ->
            !reminder.deleted &&
                    matchesStatusFilter(reminder) &&
                    matchesCategoryFilter(reminder)
        }.sortedBy { reminder ->
            getPriorityOrder(reminder.priority)
        }

        reminderList.clear()
        reminderList.addAll(filteredList)
        adapter.notifyDataSetChanged()
    }

    private fun matchesStatusFilter(reminder: Reminder): Boolean {
        return when (statusFilter) {
            "Pendentes" -> !reminder.completed
            "Concluídos" -> reminder.completed
            else -> true
        }
    }

    private fun matchesCategoryFilter(reminder: Reminder): Boolean {
        return categoryFilter == "Todas" || reminder.category == categoryFilter
    }

    private fun getPriorityOrder(priority: String): Int {
        return when (priority) {
            "Alta" -> 0
            "Média" -> 1
            "Baixa" -> 2
            else -> 3
        }
    }
}