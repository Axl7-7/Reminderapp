package com.example.reminderapp

import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ReminderAdapter(
    private val reminderList: MutableList<Reminder>
) : RecyclerView.Adapter<ReminderAdapter.ReminderViewHolder>() {

    class ReminderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txtTitle: TextView = itemView.findViewById(R.id.txtTitle)
        val txtDateTime: TextView = itemView.findViewById(R.id.txtDateTime)
        val txtPriority: TextView = itemView.findViewById(R.id.txtPriority)
        val txtCategory: TextView = itemView.findViewById(R.id.txtCategory)
        val viewColor: View = itemView.findViewById(R.id.viewColor)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReminderViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_reminder, parent, false)
        return ReminderViewHolder(view)
    }

    override fun onBindViewHolder(holder: ReminderViewHolder, position: Int) {
        val reminder = reminderList[position]

        holder.txtTitle.text = reminder.title
        holder.txtDateTime.text = "${reminder.date} ${reminder.time}"
        holder.txtPriority.text = reminder.priority
        holder.txtCategory.text = "Categoria: ${reminder.category}"

        try {
            holder.viewColor.setBackgroundColor(Color.parseColor(reminder.color))
        } catch (_: Exception) {
            holder.viewColor.setBackgroundColor(Color.GRAY)
        }

        holder.itemView.alpha = if (reminder.completed) 0.5f else 1.0f

        holder.itemView.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, ReminderDetailActivity::class.java)
            intent.putExtra("reminderIndex", position)
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int = reminderList.size
}